﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuButton : MonoBehaviour
{
    public RectTransform Recttransform;
    public Image BackgroundImage;
    public Image IconImage;
    public RectTransform IconRecttransform;



}
